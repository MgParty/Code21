﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using WMB.IS.AppConnect;
using WMB.IS.MainPages;

namespace WMB.IS.Admin
{
    /// <summary>
    /// Логика взаимодействия для ArchiveofAR.xaml
    /// </summary>
    public partial class ArchiveofAR : Page
    {
        

        public ArchiveofAR()
        {
            InitializeComponent();
           
            
        } 

                private void Backtomenuarchive_Click(object sender, RoutedEventArgs e)
                {
                    AppFrame.frameMain.Navigate(new ListofAR());
                }





                private void SearchAR_Click(object sender, RoutedEventArgs e)
                {
                    using (Model1Container search = new Model1Container())
                    {
                        try
                        {

                            string Login = Convert.ToString(txblogin.Text);

                            dgarchiveofAR.ItemsSource = search.AR.Where(x => x.Login == Login).ToList();
                        }
                        catch (Exception ex) { System.Windows.MessageBox.Show(ex.Message); }


                    }
                }
            
}   }    
