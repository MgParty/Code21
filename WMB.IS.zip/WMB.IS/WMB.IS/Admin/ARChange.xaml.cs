﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WMB.IS.AppConnect;
using WMB.IS.MainPages;

namespace WMB.IS.Admin
{
    /// <summary>
    /// Логика взаимодействия для ARChange.xaml
    /// </summary>
    public partial class ARChange : Page
    {
        private AR model = new AR();

        public ARChange(AR selectedAR)
        {
            InitializeComponent();
            model = selectedAR;
            DataContext = model;

        }

        private void Change_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(model.Login))
            {
                MessageBox.Show("Please fill in the Login!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (string.IsNullOrEmpty(model.Surname))
            {
                MessageBox.Show("Please fill in the Surname!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (string.IsNullOrEmpty(model.Name))
            {
                MessageBox.Show("Please fill in the Name!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (string.IsNullOrEmpty(model.Gender))
            {
                MessageBox.Show("Please fill in the Gender!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (string.IsNullOrEmpty(model.Password))
            {
                MessageBox.Show("Please fill in the Password!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (model.PhoneNumber <= 0)
            {
                MessageBox.Show("Please fill in the PhoneNumber!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
           
          
            int ID = model.ID;
            model = AppConnect1.modelodb.AR.FirstOrDefault(x => x.ID == ID);
            model.Login = txblogin.Text;
            model.Surname = txbsurname.Text;
            model.Name = txbname.Text;
            model.Gender = Convert.ToString(txbgender.Text);
            model.PhoneNumber = int.Parse(txbphonenumber.Text);
            model.Password = Convert.ToString(txbpass.Text);

            try
            {
                AppConnect1.modelodb.SaveChanges();              
                MessageBox.Show("AR changed");
               
                AppFrame.frameMain.Navigate(new ListofAR());
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void Backtomenuchange_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new ListofAR());

        }

    }   
}   

