﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity.Core.Metadata.Edm;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using WMB.IS.AppConnect;
using WMB.IS.MainPages;

namespace WMB.IS.Admin
{
    /// <summary>
    /// Логика взаимодействия для ListofAR.xaml
    /// </summary>
    public partial class ListofAR : Page
    {
        public ListofAR()
        {
            InitializeComponent();
            using (Model1Container one = new Model1Container())
            {
                dglistofAR.ItemsSource = one.AR.ToList();
            }
        }

        private void Backtomenulist_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new Login());

        }
        private void ChangeAR_CLick(object sender, RoutedEventArgs e)
        {


            var model = (sender as Button).DataContext as AR;

            AppFrame.frameMain.Navigate(new ARChange(model));
            dglistofAR.Items.Refresh();


        }


        private void AddAR2_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new AddAR());

        }

        private void SearchAR_Click(object sender, RoutedEventArgs e)
        {
            using (Model1Container search = new Model1Container())
            {
                try
                {

                    string Login = Convert.ToString(txblogin.Text);

                    dglistofAR.ItemsSource = search.AR.Where(x => x.Login == Login).ToList();
                }
                catch (Exception ex) { System.Windows.MessageBox.Show(ex.Message); }

              
            }


        }

     
        private void DeleteAR_CLick(object sender, RoutedEventArgs e)
        {

            AR one = new AR();
            {
                try
                {
                    int ID = (dglistofAR.SelectedItem as AR).ID;
                    one = AppConnect1.modelodb.AR.FirstOrDefault(x => x.ID == ID);

                    AppConnect1.modelodb.AR.Remove(one);
                    AppConnect1.modelodb.SaveChangesAsync();
                    MessageBox.Show("AR deleted!");
                    using (Model1Container odb = new Model1Container())
                    {
                        dglistofAR.ItemsSource = odb.AR.ToList();
                    }
                }



                catch (Exception ex) { MessageBox.Show(ex.Message); }


            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            using (Model1Container one = new Model1Container())
            {
                dglistofAR.ItemsSource = one.AR.ToList();
            }

        }
    }
}





     




