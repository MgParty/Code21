﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using WMB.IS.AppConnect;
using WMB.IS.MainPages;

namespace WMB.IS.Admin
{
    /// <summary>
    /// Логика взаимодействия для AddAR.xaml
    /// </summary>
    public partial class AddAR : Page
    {
        public AddAR()
        {
            InitializeComponent();
        }
        private void Backtomenuadd_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new Menu());
        }
        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (psbpass.Password != txbpass.Text)
            {
                AddAR1.IsEnabled = false;
                psbpass.Background = Brushes.LightCoral;
                psbpass.BorderBrush = Brushes.Red;
            }
            else
            {

                AddAR1.IsEnabled = true;
                psbpass.Background = Brushes.LightGreen; ;
                psbpass.BorderBrush = Brushes.Green;
            }
            if (psbpass.Password.Length == 0)
            {
                txbpassbox.Visibility = Visibility.Visible;
            }
            else
            {
                txbpassbox.Visibility = Visibility.Hidden;
            }

        }

        private void AddAR1_Click(object sender, RoutedEventArgs e)
        {

            if (AppConnect1.modelodb.AR.Count(x => x.Login == txblogin.Text) > 0)
            {

                MessageBox.Show("Пользователь с таким логином есть!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            try
            {

                AR userobj = new AR()
                {
                    Login = Convert.ToString(txblogin.Text),
                    Surname = Convert.ToString(txbsurname.Text),
                    Name = Convert.ToString(txbname.Text),
                    Gender = Convert.ToString(txbgender.Text),
                    PhoneNumber = int.Parse(txbphonenumber.Text),
                    Password = Convert.ToString(txbpass.Text),
                    IDRole = 2


                };

                AppConnect1.modelodb.AR.Add(userobj);
                AppConnect1.modelodb.SaveChanges();
                MessageBox.Show("AR added");
                AppFrame.frameMain.Navigate(new ListofAR());

            }





            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
