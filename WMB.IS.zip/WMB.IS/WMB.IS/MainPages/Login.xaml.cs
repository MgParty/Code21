﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WMB.IS.Admin;
using WMB.IS.AppConnect;
using WMB.IS.ARPages;
using WMB.IS.ArtistPages;

namespace WMB.IS.MainPages
{
    /// <summary>
    /// Логика взаимодействия для Login.xaml
    /// </summary>
    public partial class Login : Page
    {
       
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var ARObj = AppConnect1.modelodb.AR.FirstOrDefault(x => x.Login == txblogin.Text && x.Password == txbpass.Text);
                var ArtistObj = AppConnect1.modelodb.Artist.FirstOrDefault(x => x.Login == txblogin.Text && x.Password == txbpass.Text);
              

                if (ArtistObj != null)
                {
                    var res = MessageBox.Show("Здравствуйте  " + ArtistObj.BandorArtistName + "!",


                       "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);

                    if (res == MessageBoxResult.OK)
                    {
                      
                        AppFrame.frameMain.Navigate(new MenuArtist(null));
                    }




                }

                else if (ARObj != null)
                {
                    switch (ARObj.IDRole)

                    {
                        case 1:
                            var result = MessageBox.Show("Здравствуйте, Администратор " + ARObj.Name + "!",


                         "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);

                            if (result == MessageBoxResult.OK) { AppFrame.frameMain.Navigate(new ListofAR()); }

                            break;

                        case 2:
                            var res = MessageBox.Show("Здравствуйте  " + ARObj.Name + "!",


                         "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);

                            if (res == MessageBoxResult.OK) { AppFrame.frameMain.Navigate(new RequestAR()); }

                            break;



                        default:
                            MessageBox.Show("Данные не обнаружены!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
                            break;

                    }
                }
                else { MessageBox.Show("Такого пользователя не существует!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning); }




            }
            catch (Exception Ex)
            {
                MessageBox.Show("Ошибка " + Ex.Message.ToString() + "Критическая работа приложения!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void CreateAccount_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new SingUP());
        }
    }
}
