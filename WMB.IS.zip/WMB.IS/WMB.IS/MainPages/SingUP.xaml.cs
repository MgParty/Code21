﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WMB.IS.AppConnect;

namespace WMB.IS.MainPages
{
    /// <summary>
    /// Логика взаимодействия для SingUP.xaml
    /// </summary>
    public partial class SingUP : Page
    {
        public SingUP()
        {
            InitializeComponent();
        }
        private TextBox GetTxbphonenumber()
        {
            return txbphonenumber;
        }

        private void register_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (Model1Container one = new Model1Container())
                {
                    List<Artist> users = new List<Artist>();
                    string login = txblogin.Text;
                    string name = txbname.Text;
                    int phonenumber = int.Parse(txbphonenumber.Text);
                    string password = txbpass.Text;


                    {
                        if (AppConnect1.modelodb.AR.Count(x => x.Login == txblogin.Text) > 0)
                        {

                            MessageBox.Show("Пользователь с таким логином есть!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                            return;
                        }
                        if (login.Length == 0 || login == null || name.Length == 0 || name == null || phonenumber.ToString().Length == 0 || password.Length == 0 || password == null)
                        {
                            MessageBox.Show("Введите ВСЕ значения");
                        }
                        else
                        {
                            users.Add(new Artist
                            {
                                Login = Convert.ToString(txblogin.Text),
                                BandorArtistName = Convert.ToString(txbname.Text),
                                PhoneNumber = int.Parse(txbphonenumber.Text),
                                Password = Convert.ToString(txbpass.Text),
                                IDRole = 3


                            });
                            one.Artist.AddRange(users);
                            one.SaveChanges();
                            var result = MessageBox.Show("Данные успешно добавлены!",
                      "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                            if (result == MessageBoxResult.OK) { AppFrame.frameMain.Navigate(new SingUP()); }

                        }

                    }

                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }





        }
        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (psbpass.Password != txbpass.Text)
            {
                register.IsEnabled = false;
                psbpass.Background = Brushes.LightCoral;
                psbpass.BorderBrush = Brushes.Red;
            }
            else
            {

                register.IsEnabled = true;
                psbpass.Background = Brushes.LightGreen; ;
                psbpass.BorderBrush = Brushes.Green;
            }
            if (psbpass.Password.Length == 0)
            {
                txbpassbox.Visibility = Visibility.Visible;
            }
            else
            {
                txbpassbox.Visibility = Visibility.Hidden;
            }
        }



        private void Backlogin_Click(object sender, RoutedEventArgs e)
        {

            AppFrame.frameMain.Navigate(new Login());

        }
    }
}
