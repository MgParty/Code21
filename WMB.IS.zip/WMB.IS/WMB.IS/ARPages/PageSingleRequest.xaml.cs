﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WMB.IS.AppConnect;
using WMB.IS.ArtistPages;
using Single = WMB.IS.AppConnect.Single;

namespace WMB.IS.ARPages
{
    
    /// <summary>
    /// Логика взаимодействия для SingleRequest.xaml
    /// </summary>
    public partial class PageSingleRequest : Page
    {
        
        public PageSingleRequest()
        {
            InitializeComponent();
           

            using (Model1Container odb = new Model1Container())
            {
                dgsinglerequest.ItemsSource = odb.SingleRequest.ToList();
            }
        }
        private void Artists_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new RequestAR());
        }
        private void ViewRequest_Click(object sender, RoutedEventArgs e)
        {
            var singlerequest = (sender as Button).DataContext as SingleRequest;
            AppFrame.frameMain.Navigate(new RequestSingleView(singlerequest));
        }
        private void Accept_Click(object sender, RoutedEventArgs e)
        {
         
            SingleRequest one = new SingleRequest();
            {
                try
                {
                    int ID = (dgsinglerequest.SelectedItem as SingleRequest).ID;
                    one = AppConnect1.modelodb.SingleRequest.FirstOrDefault(x => x.ID == ID);

                    AppConnect1.modelodb.SingleRequest.Remove(one);
                  

                    AppConnect1.modelodb.SaveChangesAsync();
                   
                  
                    using (Model1Container odb = new Model1Container())
                    {
                        dgsinglerequest.ItemsSource = odb.SingleRequest.ToList();
                    }
                }



                catch (Exception ex) { MessageBox.Show(ex.Message); }
 }
            


        }
        private void Reject_Click(object sender, RoutedEventArgs e)
        {
            SingleRequest one = new SingleRequest();
            {
                try
                {
                    int ID = (dgsinglerequest.SelectedItem as SingleRequest).ID;
                    one = AppConnect1.modelodb.SingleRequest.FirstOrDefault(x => x.ID == ID);

                    AppConnect1.modelodb.SingleRequest.Remove(one);
                    AppConnect1.modelodb.SaveChangesAsync();
                    MessageBox.Show("Request rejected!");
                    using (Model1Container odb = new Model1Container())
                    {
                        dgsinglerequest.ItemsSource = odb.SingleRequest.ToList();
                    }
                }



                catch (Exception ex) { MessageBox.Show(ex.Message); }


            }
        }



    }
}
