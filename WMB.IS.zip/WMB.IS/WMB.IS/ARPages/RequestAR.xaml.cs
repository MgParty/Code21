﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WMB.IS.AppConnect;
using WMB.IS.ArtistPages;
using WMB.IS.MainPages;

namespace WMB.IS.ARPages
{
    /// <summary>
    /// Логика взаимодействия для RequestAR.xaml
    /// </summary>
    public partial class RequestAR : Page
    {
        public RequestAR()
        {
            InitializeComponent();
            using (Model1Container one = new Model1Container())
            {
                dglistofartist.ItemsSource = one.Artist.ToList();
            }
        }

        private void Backtomenulist_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new Login());
        }
        private void Blockartist_Click(object sender, RoutedEventArgs e)
        {
            Artist one = new Artist();
            {
                try
                {
                    int ID = (dglistofartist.SelectedItem as Artist).ID;
                    one = AppConnect1.modelodb.Artist.FirstOrDefault(x => x.ID == ID);

                    AppConnect1.modelodb.Artist.Remove(one);
                    AppConnect1.modelodb.SaveChangesAsync();
                    MessageBox.Show("Artist blocked!");
                    using (Model1Container odb = new Model1Container())
                    {
                        dglistofartist.ItemsSource = odb.Artist.ToList();
                    }
                }



                catch (Exception ex) { MessageBox.Show(ex.Message); }


            }

        }
        private void ViewArtist_Click(object sender, RoutedEventArgs e)
        {
            var artist= (sender as Button).DataContext as Artist;
         
            AppFrame.frameMain.Navigate(new ArtistView(artist));
        }

        private void Singlereq_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new PageSingleRequest());
        }

        private void SearchArtist_Click(object sender, RoutedEventArgs e)
        {
            using (Model1Container search = new Model1Container())
            {
                try
                {

                    string Name = Convert.ToString(txbname.Text);

                    dglistofartist.ItemsSource = search.Artist.Where(x => x.Login == Name).ToList();
                }
                catch (Exception ex) { System.Windows.MessageBox.Show(ex.Message); }


            }
        }
    }
}
