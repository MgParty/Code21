﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMB.IS.AppConnect
{
    internal class AppConnect1
    {
        public static Model1Container modelodb;
    }
}
