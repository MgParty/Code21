﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WMB.IS.Admin;
using WMB.IS.AppConnect;
using WMB.IS.MainPages;

namespace WMB.IS.ArtistPages
{
    /// <summary>
    /// Логика взаимодействия для AddAlbum.xaml
    /// </summary>
    public partial class AddAlbum : Page
    {
        public AddAlbum()
        {
            InitializeComponent();
        }

        private void AddAlbum1_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                Album album= new Album()
                {

                    Genre = Convert.ToString(txbgenre.Text),
                    Name = Convert.ToString(txbname.Text),
                   
                    Describtion = Convert.ToString(txbdescribtion.Text),
                  


                };

                AppConnect1.modelodb.Album.Add(album);
                AppConnect1.modelodb.SaveChanges();
                MessageBox.Show("Album added");
                

            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void Backtomenualadd_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new ArtistAlbums());
        }

    }
}
