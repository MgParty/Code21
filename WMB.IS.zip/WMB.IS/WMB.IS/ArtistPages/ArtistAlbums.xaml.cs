﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WMB.IS.AppConnect;
using WMB.IS.MainPages;

namespace WMB.IS.ArtistPages
{
    /// <summary>
    /// Логика взаимодействия для ArtistAlbums.xaml
    /// </summary>
    public partial class ArtistAlbums : Page
    {
        public ArtistAlbums()
        {
            InitializeComponent();
            using (Model1Container one = new Model1Container())
            {
                dglistofalbums.ItemsSource = one.Album.ToList();
            }
        }

        private void Singles_click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new MenuArtist(null));
        }

        private void Backtomenulist_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new Login());
        }

        private void AddAlbum_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new AddAlbum());
        }

        private void DeleteAlbum_Click(object sender, RoutedEventArgs e)
        {
            Album one = new Album();
            {
                try
                {
                    int ID = (dglistofalbums.SelectedItem as Album).ID;
                    one = AppConnect1.modelodb.Album.FirstOrDefault(x => x.ID == ID);

                    AppConnect1.modelodb.Album.Remove(one);
                    AppConnect1.modelodb.SaveChangesAsync();
                    MessageBox.Show("Album deleted!");
                    using (Model1Container odb = new Model1Container())
                    {
                        dglistofalbums.ItemsSource = odb.Album.ToList();
                    }
                }



                catch (Exception ex) { MessageBox.Show(ex.Message); }


            }

        }
        private void viewalbum(object sender, RoutedEventArgs e)
        {

            var album = (sender as Button).DataContext as Album;
            AppFrame.frameMain.Navigate(new ViewAlbum(album));
        }
    }
}
