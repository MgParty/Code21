﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WMB.IS.AppConnect;

namespace WMB.IS.ArtistPages
{
    /// <summary>
    /// Логика взаимодействия для AddSonginAlbum.xaml
    /// </summary>
    public partial class AddSonginAlbum : Page
    {
        public AddSonginAlbum()
        {
            InitializeComponent();
        }

        private void Backtomenuadd_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new ViewAlbum(null));
        }

        private void AddSong1_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                Song song = new Song()
                {


                    Genre = Convert.ToString(txbgenre.Text),
                    Name = Convert.ToString(txbname.Text),
                    Feat = Convert.ToString(txbfeat.Text),
                    Describtion = Convert.ToString(txbdescribtion.Text),
                    Lyrics = Convert.ToString(txblyrics.Text),



                };

                AppConnect1.modelodb.Song.Add(song);
                AppConnect1.modelodb.SaveChanges();
                MessageBox.Show("Song added");


            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
