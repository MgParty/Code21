﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WMB.IS.Admin;
using WMB.IS.AppConnect;

namespace WMB.IS.ArtistPages
{


    /// <summary>
    /// Логика взаимодействия для ViewAlbum.xaml
    /// </summary>
    public partial class ViewAlbum : Page
    {
        private Album album = new Album();
        public ViewAlbum(Album selectedAlbum)
        {
            InitializeComponent();
            album = selectedAlbum;
            DataContext = album;
            using (Model1Container one = new Model1Container())
            {
                dglistofsongs.ItemsSource = one.Song.ToList();
            }

        }
        private void Backtomenulist_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new ArtistAlbums());

        }

        private void AddSong_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new AddSonginAlbum());

        }
        private void deletesongclick(object sender, RoutedEventArgs e)
        {
            Song one = new Song();
            {
                try
                {
                    int ID = (dglistofsongs.SelectedItem as Song).ID;
                    one = AppConnect1.modelodb.Song.FirstOrDefault(x => x.ID == ID);

                    AppConnect1.modelodb.Song.Remove(one);
                    AppConnect1.modelodb.SaveChangesAsync();
                    MessageBox.Show("Song deleted!");
                    using (Model1Container odb = new Model1Container())
                    {
                        dglistofsongs.ItemsSource = odb.Song.ToList();
                    }
                }



                catch (Exception ex) { MessageBox.Show(ex.Message); }


            }
        }
    }
}
