﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WMB.IS.Admin;
using WMB.IS.AppConnect;
using WMB.IS.ARPages;
using WMB.IS.MainPages;
using Single = WMB.IS.AppConnect.Single;

namespace WMB.IS.ArtistPages
{
    /// <summary>
    /// Логика взаимодействия для MenuArtist.xaml
    /// </summary>
    public partial class MenuArtist : Page
    {
        private Single single1 = new Single();
        public MenuArtist(Single checksingle)
        {
            InitializeComponent();
            single1 = checksingle;
            DataContext= single1;
           

            using (Model1Container one = new Model1Container())
            {
                dglistofsingles.ItemsSource = one.Single.ToList();
            }
        }

        private void SearchSingle_Click(object sender, RoutedEventArgs e)
        {
            using (Model1Container search = new Model1Container())
            {
                try
                {

                    string Name = Convert.ToString(txbname.Text);

                    dglistofsingles.ItemsSource = search.Single.Where(x => x.Name == Name).ToList();
                }
                catch (Exception ex) { System.Windows.MessageBox.Show(ex.Message); }


            }
        }

        private void Backtomenulist_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new Login());
        }

        private void AddSingle_Click(object sender, RoutedEventArgs e)
        {
             AppFrame.frameMain.Navigate(new AddSingle());
        }

        private void DeleteSingle_Click(object sender, RoutedEventArgs e)
        {

            Single one = new Single();
            {
                try
                {
                    int ID = (dglistofsingles.SelectedItem as Single).ID;
                    one = AppConnect1.modelodb.Single.FirstOrDefault(x => x.ID == ID);

                    AppConnect1.modelodb.Single.Remove(one);
                    AppConnect1.modelodb.SaveChangesAsync();
                    MessageBox.Show("Single deleted!");
                    using (Model1Container odb = new Model1Container())
                    {
                        dglistofsingles.ItemsSource = odb.Single.ToList();
                    }
                }



                catch (Exception ex) { MessageBox.Show(ex.Message); }


            }


        }

        private void Albummove(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new ArtistAlbums());
        }

        private void SendSingle(object sender, RoutedEventArgs e)
        {
      

            var sendsingle = (sender as Button).DataContext as Single;
                    AppFrame.frameMain.Navigate(new SendSingleRequest(sendsingle));
                
            
        }

        private void AcceptSingles_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new PageAcceptedSingles());
        }
        private void View_Click(object sender, RoutedEventArgs e)
        {
            var viewsingle = (sender as Button).DataContext as Single;
            AppFrame.frameMain.Navigate(new SingleView(viewsingle));
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            using (Model1Container one = new Model1Container())
            {
                dglistofsingles.ItemsSource = one.Single.ToList();
            }
        }

    }
}

