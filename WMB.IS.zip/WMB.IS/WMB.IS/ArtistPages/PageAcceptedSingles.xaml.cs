﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WMB.IS.AppConnect;
using WMB.IS.ARPages;

namespace WMB.IS.ArtistPages
{
    /// <summary>
    /// Логика взаимодействия для PageAcceptedSingles.xaml
    /// </summary>
    public partial class PageAcceptedSingles : Page
    {
        public PageAcceptedSingles()
        {
            InitializeComponent();
            using (Model1Container one = new Model1Container())
            {
                dglistofsingles.ItemsSource = one.AcceptedSingles.ToList();
            }
        }

        private void Backtomenulist_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new MenuArtist(null));
        }

        private void SearchSingle_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Albummove(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new ArtistAlbums());
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new MenuArtist(null));
        }
    }
}
