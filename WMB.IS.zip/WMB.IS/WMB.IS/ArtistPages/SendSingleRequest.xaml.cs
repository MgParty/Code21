﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using WMB.IS.Admin;
using WMB.IS.AppConnect;
using WMB.IS.MainPages;
using Single = WMB.IS.AppConnect.Single;

namespace WMB.IS.ArtistPages
{
    /// <summary>
    /// Логика взаимодействия для SendSingleRequest.xaml
    /// </summary>
    public partial class SendSingleRequest : Page

    {
        private Single singlesend = new Single();

        public SendSingleRequest(Single selectedSingle)
        {
                InitializeComponent();
            singlesend= selectedSingle;
            DataContext = singlesend;
            MessageBox.Show("Please check the song data before submitting the request" , "Notification", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Backtomenulist_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new MenuArtist(null));
        }

        private void AddSong_Click(object sender, RoutedEventArgs e)
        {

            

            {

                SingleRequest singlerequestobj = new SingleRequest()
                {

                    ID = singlesend.ID,

                    Genre = txbgenre.Text,
                    Name = txbname.Text,
                    Feat = txbfeat.Text,
                    Describtion = Convert.ToString(txbdescribtion.Text),
                    Lyrics = txblyrics.Text
                };








                try
                {
                    AppConnect1.modelodb.SingleRequest.Add(singlerequestobj);
                    AppConnect1.modelodb.SaveChanges();
                    MessageBox.Show("Single sended");

                    AppFrame.frameMain.Navigate(new MenuArtist(null));
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }

        }
    }
}
