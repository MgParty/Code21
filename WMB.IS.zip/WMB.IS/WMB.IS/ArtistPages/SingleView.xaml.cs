﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WMB.IS.AppConnect;
using Single = WMB.IS.AppConnect.Single;

namespace WMB.IS.ArtistPages
{
    /// <summary>
    /// Логика взаимодействия для SingleView.xaml
    /// </summary>
    public partial class SingleView : Page
    {
        private Single viewsingle = new Single();
        public SingleView( Single singleview)
        {
            InitializeComponent();
            viewsingle= singleview;
            DataContext = viewsingle;
        }

        private void Backtomenulist_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new MenuArtist(null));
        }
    }
}
