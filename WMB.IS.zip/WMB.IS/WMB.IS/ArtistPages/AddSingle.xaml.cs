﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WMB.IS.Admin;
using WMB.IS.AppConnect;
using WMB.IS.MainPages;
using Single = WMB.IS.AppConnect.Single;

namespace WMB.IS.ArtistPages
{
    /// <summary>
    /// Логика взаимодействия для AddSingle.xaml
    /// </summary>
    public partial class AddSingle : Page
    {
       

        public AddSingle()
        {
            InitializeComponent();
          

        }

        private void AddSingle1_Click(object sender, RoutedEventArgs e)
        {

            try
            {

                using (Model1Container db = new Model1Container())
                {


                    

                    Single singleobj = new Single()
                    {
                        Genre = Convert.ToString(txbgenre.Text),
                        Name = Convert.ToString(txbname.Text),
                        Feat = Convert.ToString(txbfeat.Text),
                        Describtion = Convert.ToString(txbdescribtion.Text),
                        Lyrics = Convert.ToString(txblyrics.Text),



                    };





                    AppConnect1.modelodb.Single.Add(singleobj);
                    AppConnect1.modelodb.SaveChanges();
                    MessageBox.Show("Single added");
                    var single1 = (sender as Button).DataContext as Single;
                }
            }









            catch (Exception ex) { MessageBox.Show(ex.Message); }
            } 
           

        private void Backtomenuadd_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new MenuArtist(null));
        }
    }
}
